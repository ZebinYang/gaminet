from .gaminet import GAMINet

__all__ = ["GAMINet"]

__version__ = '0.5.10'
__author__ = 'Zebin Yang and Aijun Zhang'
